import Login from '@/components/Login/LoginPage'
import RegisterPage from '@/components/Login/LoginPage'

export default function Register() {
  return (
    <>
      <Login />
    </>
  )
}
