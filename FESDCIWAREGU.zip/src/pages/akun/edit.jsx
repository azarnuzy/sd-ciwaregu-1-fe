import Edit from '@/components/Akun/Edit'
import MainLayout from '@/layouts/MainLayout'

export default function EditAkun() {
  return (
    <>
      <MainLayout>
        <Edit/>
      </MainLayout>
    </>
  )
}
