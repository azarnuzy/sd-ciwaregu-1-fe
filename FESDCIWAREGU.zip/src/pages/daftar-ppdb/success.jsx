import SuccessSubmit from '@/components/FormPPDB/SuccessSubmit'
import React from 'react'

function Success() {
  return (
    <>
      <SuccessSubmit />
    </>
  )
}

export default Success
