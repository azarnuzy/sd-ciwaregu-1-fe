import Register from '@/components/Login/RegisterPage'

export default function Login() {
  return (
    <>
      <Register />
    </>
  )
}
